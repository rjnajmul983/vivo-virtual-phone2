# ভিভো V2507A কন্টেইনার-ভিত্তিক ভার্চুয়াল ফোন (নকল Root ও Guest কনসোল সহ)
**লক্ষ্য ডিভাইস:** Vivo V2507A (Non-Root, Android 16 / API 36, arm64-v8a, 16KB Page Size Compatible)

এই প্রজেক্টটি আপনার রোডম্যাপের **ধাপ ০ থেকে ধাপ ৫** পর্যন্ত সম্পূর্ণ আর্কিটেকচার এবং সোর্স কোড ধারণ করে:

## কী কী আছে এই প্রজেক্টে?
1. **ধাপ ০ (ভিত্তি ও Android 16 ইঞ্জিন):**
   - `VirtualContainerEngine.kt`: Android 16 (API 36)-এর জন্য `ActivityThread` H-Callback, `Instrumentation` এবং `IPackageManager` / `IActivityTaskManager` Binder ডায়নামিক প্রক্সি হুক।
   - Vivo V2507A-এর Android 16 কার্নেলের জন্য **16KB Page Size Alignment** (`-Wl,-z,max-page-size=16384`) সাপোর্ট।
2. **ধাপ ১ (ন্যূনতম প্রোটোটাইপ ও APK লঞ্চার):**
   - যেকোনো সাধারণ `.apk` ফাইল কন্টেইনারের ভেতরে ইনস্টল ও নিজস্ব `ProxyActivity` সারফেসে টাচ সাপোর্টসহ চালানো।
   - ৩টি বিল্ট-ইন টেস্ট অ্যাপ (ক্যালকুলেটর, রুট চেকার স্যুট, ভার্চুয়াল ফাইল ম্যানেজার) প্রি-কনফিগার করা।
3. **ধাপ ২ (নকল Root স্তর - Fake Root Layer):**
   - `io_redirect_su.cpp` এবং `FakeRootEnvironment.kt`: নেটিভ C++/JNI স্তরে `/system/bin/su` ও `/system/xbin/su` পাথ রিডাইরেকশন।
   - কন্টেইনারের ভেতর `su`, `id`, `whoami` চালালে `uid=0(root) gid=0(root) groups=0(root)` রিটার্ন করে।
   - `ro.build.tags=test-keys`, `ro.debuggable=1`, `ro.secure=0` স্পুফিং।
   - **স্পষ্ট সীমা:** এই Root শুধুমাত্র ভার্চুয়াল কন্টেইনারের ভেতরের অ্যাপগুলোর জন্য; আসল Vivo V2507A ফোনের সিস্টেম পার্টিশনে কোনো পরিবর্তন করে না।
4. **ধাপ ৩ (স্থিতিশীলতা, মাল্টি-ইনস্ট্যান্স ও ক্র্যাশ রিপোর্ট):**
   - `InstanceAndCrashManager.kt`: আলাদা ডেটা ফোল্ডার (`instance_1`, `instance_2`), ব্যাকগ্রাউন্ড ফোরগ্রাউন্ড সার্ভিস নোটিফিকেশন, ক্র্যাশ লগ ক্যাপচার এবং এক ক্লিকে **"Copy Report"** বাটন।
5. **ধাপ ৪ (Guest কনসোল ও আলাদা স্টোরেজ একীকরণ):**
   - `GuestConsoleSession.kt`: বর্তমান Guest কনসোল এবং ভার্চুয়াল কন্টেইনার সম্পূর্ণ আলাদা ডেটা ডিরেক্টরিতে (`guest_console_data/` বনাম `virtual_container_data/`) চলে, যাতে একটি ভাঙলে অন্যটির ডেটা কখনোই নষ্ট না হয়।
6. **ধাপ ৫ (বাংলা UI ও Signing Key সুরক্ষা):**
   - সম্পূর্ণ বাংলা ইন্টারফেস এবং একই `vcontainer_release.jks` সাইনিং কী কনফিগারেশন, যাতে ভবিষ্যতে অ্যাপ আপডেট করলেও আগের ইনস্টল করা অ্যাপ বা ডেটা না হারায়।

---

## কীভাবে APK তৈরি করবেন (২টি সহজ উপায়)

### উপায় ১: ফোন থেকেই GitHub Actions দিয়ে অটোমেটিক APK বিল্ড (পিসি ছাড়া)
1. একটি নতুন GitHub রিপোজিটরিতে এই ফোল্ডারের সব ফাইল আপলোড করুন।
2. রিপোজিটরির **Actions** ট্যাবে যান — `.github/workflows/build-apk.yml` স্বয়ংক্রিয়ভাবে চালু হবে।
3. ২-৩ মিনিটের মধ্যে বিল্ড শেষ হলে **Artifacts** সেকশন থেকে `VivoVirtualContainer-APK` ডাউনলোড করে আপনার Vivo V2507A ফোনে ইনস্টল করুন।

### উপায় ২: Android Studio দিয়ে বিল্ড
1. Android Studio (Ladybug বা নতুন)-এ প্রজেক্টটি ওপেন করুন।
2. SDK Manager থেকে **Android SDK Platform 35/36** এবং **NDK (Side by side)** ইনস্টল থাকতে হবে।
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` ক্লিক করুন।
