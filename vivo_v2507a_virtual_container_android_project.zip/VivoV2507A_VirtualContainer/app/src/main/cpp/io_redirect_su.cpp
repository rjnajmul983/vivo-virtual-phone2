#include <jni.h>
#include <string>
#include <cstring>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <android/log.h>

#define LOG_TAG "VContainerNative"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

static std::string g_fake_su_path = "";
static std::string g_fake_build_prop_path = "";
static std::string g_instance_root_dir = "";
static bool g_fake_root_enabled = true;
static int g_simulated_uid = 0;

/**
 * Resolves a virtual path requested by a guest APK inside the container.
 * When Fake Root is enabled:
 *   /system/bin/su, /system/xbin/su, /sbin/su -> redirected to container's fake su script/binary
 *   /system/build.prop -> redirected to spoofed test-keys build.prop
 */
static const char* redirect_path_if_needed(const char* original_path) {
    if (!original_path) return original_path;
    if (g_fake_root_enabled) {
        if (strcmp(original_path, "/system/bin/su") == 0 ||
            strcmp(original_path, "/system/xbin/su") == 0 ||
            strcmp(original_path, "/sbin/su") == 0 ||
            strcmp(original_path, "/su/bin/su") == 0) {
            if (!g_fake_su_path.empty()) {
                LOGI("Redirected su lookup: %s -> %s", original_path, g_fake_su_path.c_str());
                return g_fake_su_path.c_str();
            }
        }
        if (strcmp(original_path, "/system/build.prop") == 0 && !g_fake_build_prop_path.empty()) {
            return g_fake_build_prop_path.c_str();
        }
    }
    return original_path;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vivo_vcontainer_root_FakeRootEnvironment_nativeInitFakeRoot(
        JNIEnv* env,
        jobject /* this */,
        jstring fakeSuPath,
        jstring fakeBuildPropPath,
        jstring instanceRootDir,
        jboolean enableFakeRoot) {

    const char* su_c = env->GetStringUTFChars(fakeSuPath, nullptr);
    const char* prop_c = env->GetStringUTFChars(fakeBuildPropPath, nullptr);
    const char* inst_c = env->GetStringUTFChars(instanceRootDir, nullptr);

    g_fake_su_path = su_c ? su_c : "";
    g_fake_build_prop_path = prop_c ? prop_c : "";
    g_instance_root_dir = inst_c ? inst_c : "";
    g_fake_root_enabled = (enableFakeRoot == JNI_TRUE);
    g_simulated_uid = g_fake_root_enabled ? 0 : 10245;

    if (su_c) env->ReleaseStringUTFChars(fakeSuPath, su_c);
    if (prop_c) env->ReleaseStringUTFChars(fakeBuildPropPath, prop_c);
    if (inst_c) env->ReleaseStringUTFChars(instanceRootDir, inst_c);

    // Ensure fake su file is executable inside container sandbox
    if (!g_fake_su_path.empty()) {
        chmod(g_fake_su_path.c_str(), 0755);
    }

    LOGI("Initialized VContainer Native Layer (Android 16 16KB aligned). FakeRoot=%d", g_fake_root_enabled);
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_vivo_vcontainer_root_FakeRootEnvironment_nativeResolveVirtualPath(
        JNIEnv* env,
        jobject /* this */,
        jstring requestedPath) {
    const char* req_c = env->GetStringUTFChars(requestedPath, nullptr);
    const char* resolved = redirect_path_if_needed(req_c);
    jstring result = env->NewStringUTF(resolved ? resolved : "");
    if (req_c) env->ReleaseStringUTFChars(requestedPath, req_c);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_com_vivo_vcontainer_root_FakeRootEnvironment_nativeGetSimulatedUid(
        JNIEnv* /* env */,
        jobject /* this */) {
    return g_fake_root_enabled ? 0 : getuid();
}
