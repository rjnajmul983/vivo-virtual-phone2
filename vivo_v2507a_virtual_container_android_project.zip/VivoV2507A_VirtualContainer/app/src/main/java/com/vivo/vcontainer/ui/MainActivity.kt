package com.vivo.vcontainer.ui

import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import com.vivo.vcontainer.engine.VirtualContainerEngine
import com.vivo.vcontainer.root.FakeRootEnvironment
import java.io.File

/**
 * Phase 4 & 5: Main Host Activity combining Virtual Apps, Fake Root Control,
 * Separate Guest Console, File Import Bridge, and Crash Reporter in Bengali.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Instance #1 Fake Root Environment on startup
        val instance1Root = VirtualContainerEngine.getInstanceRootDir(this, 1)
        FakeRootEnvironment.setupContainerFakeRootFiles(this, instance1Root)

        // Ensure Guest Console storage is strictly separated
        File(filesDir, "guest_console_isolated_data").mkdirs()

        val webView = WebView(this)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/virtual_phone_ui.html")
    }
}
