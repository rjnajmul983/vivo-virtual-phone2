package com.vivo.vcontainer.stability

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder

/**
 * Phase 3: Foreground Service to keep Virtual Container & Multi-Instance apps alive in background.
 */
class VirtualContainerDaemonService : Service() {
    override fun onCreate() {
        super.onCreate()
        val channelId = "vcontainer_daemon_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "ভার্চুয়াল কন্টেইনার ব্যাকগ্রাউন্ড সার্ভিস",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
            val notification = Notification.Builder(this, channelId)
                .setContentTitle("ভার্চুয়াল ফোন সচল আছে")
                .setContentText("Vivo V2507A কন্টেইনার ও নকল Root স্তর ব্যাকগ্রাউন্ডে প্রস্তুত")
                .setSmallIcon(android.R.drawable.sym_def_app_icon)
                .build()
            startForeground(1001, notification)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
