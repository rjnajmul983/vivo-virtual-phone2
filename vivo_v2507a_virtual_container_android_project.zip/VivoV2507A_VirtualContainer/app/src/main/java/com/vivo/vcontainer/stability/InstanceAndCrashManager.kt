package com.vivo.vcontainer.stability

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Phase 3: Stability, Crash Logs & One-Click "Copy Report" Button,
 * plus Android 16 Compatibility List for Vivo V2507A.
 */
data class CompatibilityEntry(
    val appCategory: String,
    val exampleApps: String,
    val statusBn: String,
    val worksInContainer: Boolean,
    val technicalReasonBn: String
)

object InstanceAndCrashManager {

    private const val CRASH_LOG_FILE = "vcontainer_crash_reports.log"

    fun installGlobalCrashHandler(context: Context) {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                recordExceptionReport(context, "UncaughtException on ${thread.name}", throwable)
            } catch (_: Throwable) {}
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    fun recordExceptionReport(context: Context, tag: String, throwable: Throwable): String {
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val report = buildString {
            appendLine("=== VIVO V2507A VIRTUAL CONTAINER DIAGNOSTIC REPORT ===")
            appendLine("Time: $timestamp")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE} / SDK ${Build.VERSION.SDK_INT})")
            appendLine("Tag: $tag")
            appendLine("Stacktrace:")
            appendLine(sw.toString())
            appendLine("=======================================================")
        }
        File(context.filesDir, CRASH_LOG_FILE).appendText(report + "\n")
        return report
    }

    fun getAllCrashReports(context: Context): String {
        val f = File(context.filesDir, CRASH_LOG_FILE)
        return if (f.exists()) f.readText() else "কোনো ক্র্যাশ লগ পাওয়া যায়নি। সিস্টেম স্থিতিশীল আছে।"
    }

    fun copyCrashReportToClipboard(context: Context): Boolean {
        val text = getAllCrashReports(context)
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("VContainer Crash Report", text))
        return true
    }

    fun getAndroid16CompatibilityList(): List<CompatibilityEntry> = listOf(
        CompatibilityEntry(
            "ইউটিলিটি ও সাধারণ টুলস",
            "Calculator, Simple Notes, File Manager, CPU-Z",
            "সম্পূর্ণ সচল (১০০%)",
            true,
            "Android 16 ProxyActivity ও 16KB পেজ অ্যালাইনমেন্টে নির্বিঘ্নে চলে।"
        ),
        CompatibilityEntry(
            "রুট চেকার ও টার্মিনাল অ্যাপ",
            "Root Checker Basic, DevCheck, BusyBox Checker, Material Terminal",
            "সম্পূর্ণ সচল (নকল Root সহ)",
            true,
            "/system/bin/su রিডাইরেকশন ও uid=0 স্পুফিংয়ের মাধ্যমে Root সনাক্ত করে।"
        ),
        CompatibilityEntry(
            "ফাইল এডিটর ও স্ক্রিপ্ট টুল",
            "MT Manager (Virtual Mode), APK Editor, JSON/XML Viewer",
            "সচল (কন্টেইনার স্কোপে)",
            true,
            "কন্টেইনারের নিজস্ব ডেটা ফোল্ডার ও ইমপোর্ট করা ফাইলে পূর্ণ রিড/রাইট সুবিধা পায়।"
        ),
        CompatibilityEntry(
            "ব্যাংকিং ও পেমেন্ট অ্যাপ",
            "bKash, Nagad, Google Wallet, Banking Apps",
            "ঝুঁকিপূর্ণ / অসমর্থিত",
            false,
            "Play Integrity (Hardware Attestation) ও নকল পরিবেশ সনাক্ত করে ব্লক করতে পারে। তবে 'Hide Fake Root' মোড দিলে সাধারণ চেক পাস করে।"
        ),
        CompatibilityEntry(
            "কঠোর কার্নেল অ্যান্টি-চিট গেম",
            "Free Fire, PUBG Mobile, Genshin Impact",
            "অসমর্থিত (ব্যান ঝুঁকি)",
            false,
            "রোডম্যাপের নীতিমালা অনুযায়ী অ্যান্টি-চিট বাইপাস তৈরি করা হয়নি; কন্টেইনারে চালালে অ্যাকাউন্ট ব্যান হতে পারে।"
        ),
        CompatibilityEntry(
            "কার্নেল মডিউল / আসল সিস্টেম ফ্ল্যাশার",
            "Kernel Adiutor (Real Freq), Real Partition Flasher, Custom Recovery",
            "অসমর্থিত (হার্ডওয়্যার সীমা)",
            false,
            "নন-রুট Vivo V2507A-এর আসল কার্নেল বা `/dev/block` পরিবর্তন করা সম্ভব নয়।"
        )
    )
}
