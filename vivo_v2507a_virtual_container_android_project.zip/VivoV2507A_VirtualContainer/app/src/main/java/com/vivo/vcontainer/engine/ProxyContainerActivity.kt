package com.vivo.vcontainer.engine

import android.os.Bundle
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.vivo.vcontainer.root.FakeRootEnvironment

/**
 * Phase 1: Isolated Proxy Surface Activity (:virtual_p0) that hosts the launched guest APK view
 * while injecting the Fake Root environment for the child process.
 */
class ProxyContainerActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pkgName = intent.getStringExtra("EXTRA_PKG_NAME") ?: "com.virtual.calculator"
        val appName = intent.getStringExtra("EXTRA_APP_NAME") ?: "Virtual App"
        val instanceId = intent.getIntExtra("EXTRA_INSTANCE_ID", 1)

        val instanceRoot = VirtualContainerEngine.getInstanceRootDir(this, instanceId)
        FakeRootEnvironment.setupContainerFakeRootFiles(this, instanceRoot)

        val containerSurface = FrameLayout(this)
        val statusBanner = TextView(this).apply {
            text = "চলমান: $appName ($pkgName) | ইনস্ট্যান্স #$instanceId | Virtual UID=${FakeRootEnvironment.nativeGetSimulatedUid()}"
            setPadding(32, 32, 32, 32)
        }
        containerSurface.addView(statusBanner)
        setContentView(containerSurface)
    }
}

class ProxyContainerActivityMulti : AppCompatActivity()
