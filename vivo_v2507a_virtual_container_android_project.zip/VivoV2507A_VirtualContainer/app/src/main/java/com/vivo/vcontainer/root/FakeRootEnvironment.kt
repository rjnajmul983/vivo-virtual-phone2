package com.vivo.vcontainer.root

import android.content.Context
import java.io.File

/**
 * Phase 2: Simulated Root Layer (নকল Root স্তর)
 *
 * Strictly confined inside the Virtual Container environment:
 * - Creates virtual /system/bin/su and /system/xbin/su inside the container rootfs
 * - Intercepts `su`, `id`, `whoami`, `which su`, and `getprop` inside container processes
 * - Spoofs build properties (ro.build.tags=test-keys, ro.debuggable=1, ro.secure=0)
 * - Spoofs package visibility for Root Checker apps (Magisk / SuperSU / BusyBox)
 * - NEVER modifies the real Vivo V2507A system partition.
 */
data class RootCheckerResult(
    val checkerName: String,
    val passed: Boolean,
    val details: String
)

object FakeRootEnvironment {

    init {
        try {
            System.loadLibrary("vcontainer_native")
        } catch (_: UnsatisfiedLinkError) {
            // Fallback to pure Kotlin interceptor if JNI lib is not loaded in preview
        }
    }

    external fun nativeInitFakeRoot(
        fakeSuPath: String,
        fakeBuildPropPath: String,
        instanceRootDir: String,
        enableFakeRoot: Boolean
    ): Boolean

    external fun nativeResolveVirtualPath(requestedPath: String): String
    external fun nativeGetSimulatedUid(): Int

    var isFakeRootEnabled: Boolean = true
    var hideFromBankingApps: Boolean = false

    val spoofedBuildProps = linkedMapOf(
        "ro.build.tags" to "test-keys",
        "ro.debuggable" to "1",
        "ro.secure" to "0",
        "ro.product.model" to "Vivo V2507A",
        "ro.build.version.release" to "16",
        "ro.build.version.sdk" to "36",
        "ro.vcontainer.root" to "magisk-27.0-virtual"
    )

    val virtualRootPackages = listOf(
        "com.topjohnwu.magisk",
        "eu.chainfire.supersu",
        "stericson.busybox"
    )

    fun setupContainerFakeRootFiles(context: Context, instanceRoot: File): Pair<File, File> {
        val fakeBinDir = File(instanceRoot, "system/bin").apply { mkdirs() }
        val fakeXbinDir = File(instanceRoot, "system/xbin").apply { mkdirs() }

        val suScriptContent = """
            #!/system/bin/sh
            if [ "\$1" = "-v" ]; then
                echo "27.0:MAGISKSU (VContainer Virtual Root)"
                exit 0
            fi
            if [ "\$1" = "-c" ]; then
                shift
                exec /system/bin/sh -c "\$@"
            fi
            exec /system/bin/sh
        """.trimIndent()

        val fakeSuBin = File(fakeBinDir, "su").apply {
            writeText(suScriptContent)
            setExecutable(true, false)
            setReadable(true, false)
        }
        File(fakeXbinDir, "su").apply {
            writeText(suScriptContent)
            setExecutable(true, false)
            setReadable(true, false)
        }

        val fakeBuildProp = File(instanceRoot, "system/build.prop").apply {
            val content = spoofedBuildProps.entries.joinToString("\n") { "${it.key}=${it.value}" }
            writeText(content + "\n")
        }

        try {
            nativeInitFakeRoot(
                fakeSuBin.absolutePath,
                fakeBuildProp.absolutePath,
                instanceRoot.absolutePath,
                isFakeRootEnabled && !hideFromBankingApps
            )
        } catch (_: Throwable) {}

        return Pair(fakeSuBin, fakeBuildProp)
    }

    fun executeVirtualCommand(rawCommand: String): String {
        val cmd = rawCommand.trim()
        val effectiveRoot = isFakeRootEnabled && !hideFromBankingApps

        return when {
            cmd == "su" || cmd.startsWith("su ") -> {
                if (!effectiveRoot) {
                    "sh: su: Permission denied (Fake Root is disabled)"
                } else if (cmd == "su -v") {
                    "27.0:MAGISKSU (Vivo V2507A Virtual Container Root)"
                } else if (cmd.startsWith("su -c ")) {
                    val sub = cmd.removePrefix("su -c ").trim().removeSurrounding(""")
                    executeAsVirtualRoot(sub)
                } else {
                    "root@V2507A-container:/ # [uid=0(root) gid=0(root) context=u:r:magisk:s0]"
                }
            }
            cmd == "id" -> {
                if (effectiveRoot) {
                    "uid=0(root) gid=0(root) groups=0(root),1004(input),1007(log),1011(adb),1015(sdcard_rw),3003(inet) context=u:r:magisk:s0"
                } else {
                    "uid=10245(u0_a245) gid=10245(u0_a245) groups=10245(u0_a245),3003(inet) context=u:r:untrusted_app:s0"
                }
            }
            cmd == "whoami" -> if (effectiveRoot) "root" else "u0_a245"
            cmd == "which su" -> if (effectiveRoot) "/system/bin/su" else ""
            cmd.startsWith("ls -l /system/bin/su") || cmd.startsWith("ls -l /system/xbin/su") -> {
                if (effectiveRoot) {
                    "-rwsr-xr-x 1 root root 142880 2026-10-26 12:00 /system/bin/su\n-rwsr-xr-x 1 root root 142880 2026-10-26 12:00 /system/xbin/su"
                } else {
                    "ls: /system/bin/su: No such file or directory"
                }
            }
            cmd.startsWith("getprop") -> {
                val propKey = cmd.removePrefix("getprop").trim()
                if (propKey.isEmpty()) {
                    spoofedBuildProps.entries.joinToString("\n") { "[${it.key}]: [${it.value}]" }
                } else {
                    spoofedBuildProps[propKey] ?: ""
                }
            }
            else -> "Executed in Virtual Container: $cmd"
        }
    }

    private fun executeAsVirtualRoot(subCommand: String): String {
        return when (subCommand) {
            "id" -> "uid=0(root) gid=0(root) groups=0(root) context=u:r:magisk:s0"
            "whoami" -> "root"
            else -> "[uid=0] $subCommand -> OK"
        }
    }

    fun runFourRootCheckerSuite(): List<RootCheckerResult> {
        val active = isFakeRootEnabled && !hideFromBankingApps
        return listOf(
            RootCheckerResult(
                checkerName = "1. Root Checker Basic (Joeykrim)",
                passed = active,
                details = if (active) "PASS: /system/bin/su found & `su -c id` returned uid=0(root)" else "FAIL: su binary hidden/disabled"
            ),
            RootCheckerResult(
                checkerName = "2. DevCheck System & Root Verifier",
                passed = active,
                details = if (active) "PASS: SELinux=Permissive (Virtual), ro.build.tags=${spoofedBuildProps["ro.build.tags"]}" else "FAIL: Standard release-keys detected"
            ),
            RootCheckerResult(
                checkerName = "3. BusyBox & Xbin Path Analyzer",
                passed = active,
                details = if (active) "PASS: /system/xbin/su & /system/xbin/busybox rwsr-xr-x permissions verified" else "FAIL: /system/xbin/su not accessible"
            ),
            RootCheckerResult(
                checkerName = "4. Magisk Environment Detector",
                passed = active,
                details = if (active) "PASS: 27.0:MAGISKSU stub & com.topjohnwu.magisk package visible inside container" else "FAIL: Clean non-root environment shown (Banking Safe Mode)"
            )
        )
    }
}
