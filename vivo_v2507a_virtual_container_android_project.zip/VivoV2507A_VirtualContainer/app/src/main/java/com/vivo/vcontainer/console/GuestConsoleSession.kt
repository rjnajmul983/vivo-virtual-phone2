package com.vivo.vcontainer.console

import android.content.Context
import com.vivo.vcontainer.root.FakeRootEnvironment
import java.io.File

/**
 * Phase 4: Guest Console Integration with strictly separated storage.
 *
 * Storage path: /files/guest_console_isolated_data/
 * Even if the Virtual APK Container resets or crashes, Guest Console scripts,
 * logs, and imported files remain 100% intact.
 */
class GuestConsoleSession(private val context: Context) {

    val isolatedConsoleDir: File by lazy {
        File(context.filesDir, "guest_console_isolated_data").apply { mkdirs() }
    }

    fun executeConsoleCommand(input: String): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return ""
        return when (trimmed) {
            "help" -> """
                Guest কনসোল কমান্ড তালিকা:
                - su              : ভার্চুয়াল Root শেল চালু করুন (uid=0)
                - id / whoami     : বর্তমান ইউজার ও গ্রুপ আইডি দেখুন
                - ls -l /system/bin/su : নকল su বাইনারি যাচাই করুন
                - getprop         : স্পুফ করা Android 16 Build Properties দেখুন
                - pwd             : আলাদা Guest কনসোল স্টোরেজ পাথ দেখুন
                - storage-status  : Guest কনসোল ও কন্টেইনারের ডেটা বিচ্ছিন্নতা যাচাই করুন
            """.trimIndent()
            "pwd" -> isolatedConsoleDir.absolutePath
            "storage-status" -> "Guest Console Storage: ${isolatedConsoleDir.absolutePath} (Isolated from Virtual Container)"
            else -> FakeRootEnvironment.executeVirtualCommand(trimmed)
        }
    }
}
