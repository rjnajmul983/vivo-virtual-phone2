package com.vivo.vcontainer

import android.app.Application
import com.vivo.vcontainer.stability.InstanceAndCrashManager

class VirtualPhoneApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Install Phase 3 Global Crash Handler immediately
        InstanceAndCrashManager.installGlobalCrashHandler(this)
    }
}
