plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vivo.vcontainer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.vivo.vcontainer"
        minSdk = 29
        targetSdk = 35
        versionCode = 100
        versionName = "1.0.0-vivo-v2507a"

        ndk {
            // Vivo V2507A runs 64-bit ARMv8/v9 architecture
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                // Critical for Android 15/16 on Vivo V2507A: 16KB page size alignment
                cppFlags += "-std=c++17 -O2"
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    signingConfigs {
        create("consistentKey") {
            storeFile = file("keystore/vcontainer_consistent.jks")
            storePassword = System.getenv("KEYSTORE_PASS") ?: "vivo2507a"
            keyAlias = "vcontainer_key"
            keyPassword = System.getenv("KEY_PASS") ?: "vivo2507a"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.findByName("consistentKey") ?: signingConfigs.getByName("debug")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("consistentKey")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
